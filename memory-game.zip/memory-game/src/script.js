const emojis = ['🍎', '🍌', '🍇', '🍓', '🍎', '🍌', '🍇', '🍓'];
let shuffled = emojis.sort(() => 0.5 - Math.random());
let gameBoard = document.getElementById('game-board');
let flippedCards = [];
let matchedCards = [];
let moves = 0;

function createBoard() {
  gameBoard.innerHTML = '';
  shuffled.forEach((emoji, index) => {
    let card = document.createElement('div');
    card.classList.add('card');
    card.dataset.index = index;
    card.innerText = '';
    card.addEventListener('click', flipCard);
    gameBoard.appendChild(card);
  });
  document.getElementById('moves').innerText = 'Moves: 0';
  moves = 0;
  matchedCards = [];
}

function flipCard() {
  let index = this.dataset.index;
  if (flippedCards.includes(index) || matchedCards.includes(index)) return;

  this.innerText = shuffled[index];
  this.classList.add('flipped');
  flippedCards.push(index);

  if (flippedCards.length === 2) {
    moves++;
    document.getElementById('moves').innerText = `Moves: ${moves}`;
    let [first, second] = flippedCards;
    if (shuffled[first] === shuffled[second]) {
      matchedCards.push(first, second);
    } else {
      setTimeout(() => {
        document.querySelector(`[data-index='${first}']`).innerText = '';
        document.querySelector(`[data-index='${second}']`).innerText = '';
        document.querySelector(`[data-index='${first}']`).classList.remove('flipped');
        document.querySelector(`[data-index='${second}']`).classList.remove('flipped');
      }, 1000);
    }
    flippedCards = [];
  }
}

function restartGame() {
  shuffled = emojis.sort(() => 0.5 - Math.random());
  createBoard();
}

createBoard();